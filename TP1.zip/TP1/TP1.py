# Configuration de la pompe à essence
print("Configuration de la pompe à essence ...")
prix_ordinaire = float(input("Prix de l'essence ordinaire ($/L) : "))
if prix_ordinaire > 0:
    prix_ordinaire = prix_ordinaire
elif prix_ordinaire <= 0:
    print("Veuillez entrer une valeur supérieure à 0.")
    prix_ordinaire = float(input("Prix de l'essence ordinaire ($/L) : "))
prix_diesel = float(input("Prix de l'essence diesel ($/L) : "))
if prix_diesel > 0:
    prix_diesel = prix_diesel
elif prix_diesel <= 0:
    print("Veuillez entrer une valeur supérieure à 0.")
    prix_diesel = float(input("Prix de l'essence diesel ($/L) : "))
prix_super = 1.1 * prix_ordinaire
code_secret = str(input("Le code secret du jour est : "))
print("∗∗∗∗∗∗∗∗∗∗")

# Arrivée d'une automobile
print("Une automobile arrive.")
reservoire_total = float(input("Le nombre de litres total de son réservoir est "))
essence_contenue = float(input("et il en contient actuellement "))
if essence_contenue >= reservoire_total:
    essence_contenue = float(input("Veuillez entrer un nombre inférieur à : ", reservoire_total, ": "))
print("   ")

# Demander le type d'essence
print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
print("- - -  - - - - - - - - - - - - - - Affichage sur la pompe - - - - - - - - - - - - - - - - - - - - -")
print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
print("Veuillez sélectionner le type d'essence parmi :")
print("- [O] rdinaire :", prix_ordinaire, "$ / litre")
print("- [S] uper :", "{:.2f}".format(prix_super), "$ / litre")
print("- [D] iesel :", prix_diesel, "$ / litre")
choix_essence = str(input("Votre choix (O, S ou D) : "))
if choix_essence == "O":
    choix_essence = prix_ordinaire
elif choix_essence == "o":
    choix_essence = prix_ordinaire
elif choix_essence == "S":
    choix_essence = prix_super
elif choix_essence == "s":
    choix_essence = prix_super
elif choix_essence == "D":
    choix_essence = prix_diesel
elif choix_essence == "d":
    choix_essence = prix_diesel
elif choix_essence != "O" or "o" or "S" or "s" or "D" or "d":
    choix_essence = str(input("Veuilez choisir parmi (O, S ou D) : "))
    if choix_essence == "O":
        choix_essence = prix_ordinaire
    elif choix_essence == "o":
        choix_essence = prix_ordinaire
    elif choix_essence == "S":
        choix_essence = prix_super
    elif choix_essence == "s":
        choix_essence = prix_super
    elif choix_essence == "D":
        choix_essence = prix_diesel
    elif choix_essence == "d":
        choix_essence = prix_diesel

# Demander le plein ou un montant fixe et Remplissage litre par litre
plein_fixe = str(input("Souhaitez-vous faire le plein (P) ou choisir un montant fixe (M) ? "))
print("Remplissage !")
cout_cumulatif = 0
montant_fixe = 0
cout_final = 0
if plein_fixe == "P":
    incrementation_essence = essence_contenue + 1
    calcul_cout = (incrementation_essence - essence_contenue) * choix_essence
    cout_cumulatif = calcul_cout
    litre_litre = str(input("Appuyez sur entrée pour ajouter un litre (A pour arrêter). "))
    if litre_litre == "A":
        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
        cout_cumulatif = calcul_cout
        incrementation_essence = incrementation_essence - 1
        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
        incrementation_essence = reservoire_total
    elif litre_litre == "a":
        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
        cout_cumulatif = calcul_cout
        incrementation_essence = incrementation_essence - 1
        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
        incrementation_essence = reservoire_total
    elif litre_litre != "A" or "a":
        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
        while incrementation_essence <= (reservoire_total - 1):
            incrementation_essence = incrementation_essence + 1
            calcul_cout = (incrementation_essence - essence_contenue) * choix_essence
            cout_cumulatif = calcul_cout
            litre_litre = str(input("Appuyez sur entrée pour ajouter un litre (A pour arrêter). "))
            if litre_litre == "A":
                calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                cout_cumulatif = calcul_cout
                incrementation_essence = incrementation_essence - 1
                print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                incrementation_essence = reservoire_total
            elif litre_litre == "a":
                calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                cout_cumulatif = calcul_cout
                incrementation_essence = incrementation_essence - 1
                print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                incrementation_essence = reservoire_total
            elif litre_litre != "A" or "a":
                print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                if (reservoire_total - 1) < incrementation_essence < reservoire_total:
                    cout_restant = (reservoire_total - incrementation_essence) * choix_essence
                    cout_cumulatif = calcul_cout + cout_restant
                    litre_litre = str(input("Appuyez sur entrée pour ajouter un litre (A pour arrêter). "))
                    if litre_litre == "A":
                        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                        cout_cumulatif = calcul_cout
                        incrementation_essence = incrementation_essence - 1
                        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                        incrementation_essence = reservoire_total
                    elif litre_litre == "a":
                        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                        cout_cumulatif = calcul_cout
                        incrementation_essence = incrementation_essence - 1
                        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                        incrementation_essence = reservoire_total
                    elif litre_litre != "A" or "a":
                        print("État du réservoir d'essence :", reservoire_total, "litres sur", reservoire_total)
                        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                        reservoire_complet = (reservoire_total - incrementation_essence) + incrementation_essence
                        if reservoire_complet >= reservoire_total:
                            print("Terminé !")
elif plein_fixe == "p":
    incrementation_essence = essence_contenue + 1
    calcul_cout = (incrementation_essence - essence_contenue) * choix_essence
    cout_cumulatif = calcul_cout
    litre_litre = str(input("Appuyez sur entrée pour ajouter un litre (A pour arrêter). "))
    if litre_litre == "A":
        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
        cout_cumulatif = calcul_cout
        incrementation_essence = incrementation_essence - 1
        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
        incrementation_essence = reservoire_total
    elif litre_litre == "a":
        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
        cout_cumulatif = calcul_cout
        incrementation_essence = incrementation_essence - 1
        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
        incrementation_essence = reservoire_total
    elif litre_litre != "A" or "a":
        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
        while incrementation_essence <= (reservoire_total - 1):
            incrementation_essence = incrementation_essence + 1
            calcul_cout = (incrementation_essence - essence_contenue) * choix_essence
            cout_cumulatif = calcul_cout
            litre_litre = str(input("Appuyez sur entrée pour ajouter un litre (A pour arrêter). "))
            if litre_litre == "A":
                calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                cout_cumulatif = calcul_cout
                incrementation_essence = incrementation_essence - 1
                print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                incrementation_essence = reservoire_total
            elif litre_litre == "a":
                calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                cout_cumulatif = calcul_cout
                incrementation_essence = incrementation_essence - 1
                print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                incrementation_essence = reservoire_total
            elif litre_litre != "A" or "a":
                print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                if (reservoire_total - 1) < incrementation_essence < reservoire_total:
                    cout_restant = (reservoire_total - incrementation_essence) * choix_essence
                    cout_cumulatif = calcul_cout + cout_restant
                    litre_litre = str(input("Appuyez sur entrée pour ajouter un litre (A pour arrêter). "))
                    if litre_litre == "A":
                        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                        cout_cumulatif = calcul_cout
                        incrementation_essence = incrementation_essence - 1
                        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                        incrementation_essence = reservoire_total
                    elif litre_litre == "a":
                        calcul_cout = ((incrementation_essence - 1) - essence_contenue) * choix_essence
                        cout_cumulatif = calcul_cout
                        incrementation_essence = incrementation_essence - 1
                        print("État du réservoir d'essence :", incrementation_essence, "litres sur", reservoire_total)
                        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                        incrementation_essence = reservoire_total
                    elif litre_litre != "A" or "a":
                        print("État du réservoir d'essence :", reservoire_total, "litres sur", reservoire_total)
                        print("Coût (jusqu'à maintenant) : ", "{:.2f}".format(cout_cumulatif), "$")
                        reservoire_complet = (reservoire_total - incrementation_essence) + incrementation_essence
                        if reservoire_complet >= reservoire_total:
                            print("Terminé !")
elif plein_fixe == "M":
    montant_fixe = float(input("Combien d'essence voulez-vous mettre ($) ? "))
    if ((montant_fixe / choix_essence) + essence_contenue) > reservoire_total:
        montant_fixe = (reservoire_total - essence_contenue) * choix_essence
        cout_cumulatif = montant_fixe
    elif ((montant_fixe / choix_essence) + essence_contenue) <= reservoire_total:
        montant_fixe = montant_fixe
        cout_cumulatif = montant_fixe
elif plein_fixe == "m":
    montant_fixe = float(input("Combien d'essence voulez-vous mettre ($) ? "))
    if ((montant_fixe / choix_essence) + essence_contenue) > reservoire_total:
        montant_fixe = (reservoire_total - essence_contenue) * choix_essence
        cout_cumulatif = montant_fixe
    elif ((montant_fixe / choix_essence) + essence_contenue) <= reservoire_total:
        montant_fixe = montant_fixe
        cout_cumulatif = montant_fixe

# Entrer un code promotionnel
print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
code_promo = str(input("Si vous connaissez le code promotionnel RABAIS+, entrez-le maintenant pour obtenir 30% de rabais : "))
if code_promo == code_secret:
    print("Code valide.")
    if plein_fixe == "P":
        cout_final = 0.7 * cout_cumulatif
    elif plein_fixe == "p":
        cout_final = 0.7 * cout_cumulatif
    elif plein_fixe == "M":
        cout_final = 0.7 * montant_fixe
    elif plein_fixe == "m":
        cout_final = 0.7 * montant_fixe
else:
    print("Code invalide.")

# Affichage final
print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
if code_promo == code_secret:
    print("Le montant final est :", "{:.2f}".format(cout_final), "$")
    print("Faites bonne route !")
else:
    print("Le montant final est :", "{:.2f}".format(cout_cumulatif), "$")
    print("Faites bonne route !")
